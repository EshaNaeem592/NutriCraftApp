import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  ScrollView,
  StyleSheet,
  Dimensions,
  ImageBackground,
} from 'react-native';

const API_KEY = '82b165711705467dacd35f4113e0c74d';
const API_URL = 'https://api.spoonacular.com/food/ingredients/substitutes';

const { height, width } = Dimensions.get('window');

const backgroundImage = require('../../../assets/icons/Ing.jpg'); // Replace with the actual path to your image

const IngredientSubstitutes = () => {
  const [ingredientName, setIngredientName] = useState('');
  const [substitutes, setSubstitutes] = useState([]);
  const [message, setMessage] = useState('');

  const handleSearch = async () => {
    try {
      const response = await fetch(
        `${API_URL}?ingredientName=${ingredientName}&apiKey=${API_KEY}`
      );
      const data = await response.json();

      console.log('API Response:', data);

      if (data.substitutes && data.substitutes.length > 0) {
        setSubstitutes(data.substitutes);
        setMessage(data.message);
      } else {
        setSubstitutes([]);
        setMessage('No substitutes found for the ingredient.');
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setMessage('Error fetching data. Please try again.');
    }
  };

  return (
    <ImageBackground source={backgroundImage} style={styles.backgroundImage}>
      <View style={styles.centeredContainer}>
        <ScrollView contentContainerStyle={styles.container}>
          <Text style={styles.heading}>Ingredient Substitutes</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter ingredient"
            value={ingredientName}
            onChangeText={(text) => setIngredientName(text)}
          />
          <Button title="Search Ingredients" onPress={handleSearch} />

          {message && <Text style={styles.message}>{message}</Text>}

          {substitutes.length > 0 && (
            <View style={styles.substitutesContainer}>
              <Text style={styles.substitutesHeading}>Substitutes:</Text>
              {substitutes.map((substitute, index) => (
                <Text key={index} style={styles.substituteText}>
                  {substitute}
                </Text>
              ))}
            </View>
          )}
        </ScrollView>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  centeredContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 16,
    width: '100%',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
    color: 'black',
  },
  input: {
    height: 40,
    borderColor: '#8dc63f',
    borderWidth: 1,
    marginBottom: 16,
    paddingLeft: 8,
    borderRadius: 8,
    backgroundColor: 'white',
  },
  message: {
    fontSize: 16,
    marginBottom: 10,
    marginTop: 20,
    color: 'black',
    textAlign: 'center',
  },
  substitutesContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  substitutesHeading: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#8dc63f',
  },
  substituteText: {
    fontSize: 16,
    marginBottom: 5,
    color: 'black',
  },
});

export default IngredientSubstitutes;
