import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  Image,
  ScrollView,
  StyleSheet,
  Dimensions,
  ImageBackground,
} from 'react-native';

const API_KEY = '82b165711705467dacd35f4113e0c74d';
const API_URL = 'https://api.spoonacular.com/food/ingredients';

const backgroundImage = require('../../../assets/icons/info.jpg');
 // Replace with the actual path to your image

const IngredientInformation = () => {
  const [query, setQuery] = useState('');
  const [ingredientData, setIngredientData] = useState(null);

  const handleSearch = async () => {
    try {
      const response = await fetch(
        `${API_URL}/search?query=${query}&number=1&apiKey=${API_KEY}`
      );
      const data = await response.json();

      if (data.results.length > 0) {
        const ingredientId = data.results[0].id;
        const infoResponse = await fetch(
          `${API_URL}/${ingredientId}/information?amount=1&apiKey=${API_KEY}`
        );
        const infoData = await infoResponse.json();
        setIngredientData(infoData);
      } else {
        setIngredientData(null);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <ImageBackground source={backgroundImage} style={styles.backgroundImage}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>Ingredient Information</Text>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Enter ingredient"
            value={query}
            onChangeText={(text) => setQuery(text)}
          />
          <Button title="Search" onPress={handleSearch} />
        </View>

        {ingredientData && (
          <View style={styles.resultContainer}>
            <View style={styles.imageContainer}>
              <Image
                style={styles.resultImage}
                source={{
                  uri: `https://spoonacular.com/cdn/ingredients_100x100/${ingredientData.image}`,
                }}
              />
            </View>
            <Text style={styles.resultName}>{ingredientData.name}</Text>
            <Text style={styles.resultAisle}>Aisle: {ingredientData.aisle}</Text>

            <View style={styles.infoSection}>
              <Text style={styles.infoHeading}>Nutritional Information:</Text>
              {ingredientData.nutrition.nutrients.map((nutrient, index) => (
                <Text key={index} style={styles.infoText}>
                  {nutrient.name}: {nutrient.amount} {nutrient.unit} (
                  {nutrient.percentOfDailyNeeds}%)
                </Text>
              ))}
            </View>

            <View style={styles.infoSection}>
              <Text style={styles.infoHeading}>Properties:</Text>
              {ingredientData.nutrition.properties.map((property, index) => (
                <Text key={index} style={styles.infoText}>
                  {property.name}: {property.amount} {property.unit}
                </Text>
              ))}
            </View>
          </View>
        )}
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    
  },
  container: {
    flexGrow: 1,
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
    color: 'black',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  input: {
    height: 40,
    flex: 1,
    borderColor: '#8dc63f',
    borderWidth: 1,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  resultContainer: {
    alignItems: 'center',
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#8dc63f',
    padding: 10,
    borderRadius: 8,
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  resultImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  resultName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 10,
    color: 'black',
  },
  resultAisle: {
    fontSize: 16,
    marginTop: 5,
    color: 'black',
  },
  infoSection: {
    marginTop: 20,
  },
  infoHeading: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#8dc63f',
  },
  infoText: {
    fontSize: 16,
    marginBottom: 5,
    color: 'black',
  },
});

export default IngredientInformation;
