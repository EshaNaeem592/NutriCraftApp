// NutritionScreen.js

import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { DataTable, Appbar, List, Card, Divider, IconButton } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const NutritionScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Appbar.Header>
        <Appbar.Content title="NutriCraft" />
      </Appbar.Header>

      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.heading}>Essential Vitamins</Text>
        <DataTable style={styles.table}>
          <DataTable.Header>
            <DataTable.Title>Name</DataTable.Title>
            <DataTable.Title>Source</DataTable.Title>
            <DataTable.Title>Benefits</DataTable.Title>
          </DataTable.Header>

          {/* Example rows */}
          <DataTable.Row>
            <DataTable.Cell>Vitamin A</DataTable.Cell>
            <DataTable.Cell>Carrots, Spinach</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Eye health, Immunity, Skin health, Reducing inflammation
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Vitamin C</DataTable.Cell>
            <DataTable.Cell>Oranges, Broccoli</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Collagen synthesis, Antioxidant, Immune support, Wound healing
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Vitamin D</DataTable.Cell>
            <DataTable.Cell>Sunlight, Fatty fish</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Bone health, Immunity, Mental health, Regulating insulin
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Vitamin E</DataTable.Cell>
            <DataTable.Cell>Nuts, Seeds</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Antioxidant, Skin health, Heart health, Vision protection
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Vitamin K</DataTable.Cell>
            <DataTable.Cell>Leafy greens, Broccoli</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Blood clotting, Bone health, Cardiovascular health
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Vitamin B12</DataTable.Cell>
            <DataTable.Cell>Meat, Dairy</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Energy production, Red blood cell formation, Nervous system support
            </DataTable.Cell>
          </DataTable.Row>
          {/* Add more rows as needed */}
        </DataTable>

        <Text style={styles.heading}>Essential Minerals</Text>
        <DataTable style={styles.table}>
          <DataTable.Header>
            <DataTable.Title>Name</DataTable.Title>
            <DataTable.Title>Source</DataTable.Title>
            <DataTable.Title>Benefits</DataTable.Title>
          </DataTable.Header>

          {/* Example rows */}
          <DataTable.Row>
            <DataTable.Cell>Calcium</DataTable.Cell>
            <DataTable.Cell>Dairy, Nuts</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Bone health, Muscle function, Nerve transmission, Blood clotting
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Iron</DataTable.Cell>
            <DataTable.Cell>Red meat, Beans</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Oxygen transport, Immune function, Cognitive development
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Magnesium</DataTable.Cell>
            <DataTable.Cell>Leafy greens, Whole grains</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Energy production, Muscle function, Nervous system regulation
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Zinc</DataTable.Cell>
            <DataTable.Cell>Meat, Nuts</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Immune function, Wound healing, DNA synthesis, Growth
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Selenium</DataTable.Cell>
            <DataTable.Cell>Seafood, Nuts</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Antioxidant, Thyroid function, Immune system support
            </DataTable.Cell>
          </DataTable.Row>
          <DataTable.Row>
            <DataTable.Cell>Potassium</DataTable.Cell>
            <DataTable.Cell>Bananas, Potatoes</DataTable.Cell>
            <DataTable.Cell numberOfLines={2}>
              Blood pressure regulation, Fluid balance, Muscle contractions
            </DataTable.Cell>
          </DataTable.Row>
          {/* Add more rows as needed */}
        </DataTable>

        <Text style={styles.heading}>Macronutrients</Text>
        <Card style={styles.card}>
          <Card.Content>
            <List.Section>
              <List.Subheader>Proteins</List.Subheader>
              <List.Item title="Build and repair tissues" />
              <List.Item title="Enzyme and hormone production" />
              <List.Item title="Muscle development and maintenance" />
              <List.Item title="Immune system support" />
            </List.Section>

            <Divider />

            <List.Section>
              <List.Subheader>Fats</List.Subheader>
              <List.Item title="Energy source" />
              <List.Item title="Cell membrane structure" />
              <List.Item title="Absorption of fat-soluble vitamins" />
              <List.Item title="Brain health and function" />
            </List.Section>
            {/* Add more macronutrient sections as needed */}
          </Card.Content>
        </Card>
       

        <Text style={styles.heading}>Inspiration and Challenges</Text>
        <Card style={styles.card}>
          <Card.Content>
            <List.Section>
              <List.Item title="Stay consistent with your nutrition goals." />
              <List.Item title="Overcoming common challenges in meal planning." />
              <List.Item title="Find joy in trying new healthy recipes." />
              <List.Item title="Celebrate small victories along your health journey." />
            </List.Section>
          </Card.Content>
        </Card>

        <Text style={styles.heading}>Tips and Techniques</Text>
        <Card style={styles.card}>
          <Card.Content>
            <List.Section>
              <List.Item title="Use herbs and spices for flavor without added calories." />
              <List.Item title="Plan your meals ahead for a healthier lifestyle." />
              <List.Item title="Stay hydrated throughout the day." />
              <List.Item title="Incorporate a variety of colors into your meals for diverse nutrients." />
              <List.Item title="Practice mindful eating to savor each bite and recognize hunger cues." />
            </List.Section>
          </Card.Content>
        </Card>

        {/* Add more sections as needed */}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5', // Light gray background
  },
  scrollContainer: {
    padding: 16,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 10,
    color: '#00cc00', // Green color
  },
  table: {
    marginTop: 10,
  },
  card: {
    marginTop: 10,
  },
});

export default NutritionScreen;
