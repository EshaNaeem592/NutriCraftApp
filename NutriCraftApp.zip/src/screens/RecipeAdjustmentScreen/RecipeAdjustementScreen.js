// RecipeAdjustmentScreen.js
import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, FlatList, Alert, StyleSheet } from "react-native";

const RecipeAdjustmentScreen = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [servings, setServings] = useState("1");
  const [adjustedIngredients, setAdjustedIngredients] = useState([]);

  const mockRecipeData = [
    { id: "1", name: "Pasta", servings: 4, ingredients: ["Pasta", "Tomato Sauce", "Cheese"] },
    { id: "2", name: "Salad", servings: 2, ingredients: ["Lettuce", "Tomatoes", "Cucumbers"] },
    { id: "3", name: "Pizza", servings: 8, ingredients: ["Dough", "Tomato Sauce", "Cheese", "Pepperoni"] },
  ];

  const handleSearch = () => {
    const results = mockRecipeData.filter((recipe) =>
      recipe.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setSearchResults(results);
  };

  const handleAdjustRecipe = () => {
    if (selectedRecipe) {
      const adjustedIngredients = selectedRecipe.ingredients.map((ingredient) => {
        const adjustedAmount =
          (ingredient.amount / selectedRecipe.servings) * parseInt(servings, 10);
        return `${adjustedAmount} ${ingredient.name}`;
      });

      setAdjustedIngredients(adjustedIngredients);

      Alert.alert(
        "Adjusted Recipe",
        `Name: ${selectedRecipe.name}\nServings: ${servings}\nIngredients: ${adjustedIngredients.join(", ")}`,
        [
          { text: "Save", onPress: handleSaveRecipe },
          { text: "Share", onPress: handleShareRecipe },
          { text: "Cancel", style: "cancel" },
        ],
        { cancelable: true }
      );
    }
  };

  const handleSaveRecipe = () => {
    // Implement logic to save the adjusted recipe
    Alert.alert("Recipe Saved!", "The adjusted recipe has been saved.");
  };

  const handleShareRecipe = () => {
    const recipeText = `Check out this adjusted recipe: ${selectedRecipe.name} for ${servings} servings!`;
    // For demonstration purposes, just log the message to the console
    console.log(recipeText);
  };

  const renderRecipeItem = ({ item }) => (
    <TouchableOpacity
      style={styles.recipeItem}
      onPress={() => setSelectedRecipe(item)}
    >
      <Text>{item.name}</Text>
      <Text>Servings: {item.servings}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.searchInput}
        placeholder="Search for a recipe"
        value={searchQuery}
        onChangeText={(text) => setSearchQuery(text)}
      />
      <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
        <Text style={styles.searchButtonText}>Search</Text>
      </TouchableOpacity>

      <FlatList
        data={searchResults}
        keyExtractor={(item) => item.id}
        renderItem={renderRecipeItem}
      />

      {selectedRecipe && (
        <View style={styles.adjustmentContainer}>
          <Text style={styles.adjustmentLabel}>Number of Servings:</Text>
          <TextInput
            style={styles.servingsInput}
            placeholder="Enter servings"
            keyboardType="numeric"
            value={servings}
            onChangeText={(text) => setServings(text)}
          />
          <TouchableOpacity style={styles.adjustButton} onPress={handleAdjustRecipe}>
            <Text style={styles.adjustButtonText}>Adjust Recipe</Text>
          </TouchableOpacity>
        </View>
      )}

      {adjustedIngredients.length > 0 && (
        <View style={styles.adjustedIngredientsContainer}>
          <Text style={styles.adjustedIngredientsLabel}>Adjusted Ingredients:</Text>
          {adjustedIngredients.map((ingredient, index) => (
            <Text key={index}>{ingredient}</Text>
          ))}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  searchInput: {
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  searchButton: {
    backgroundColor: "#8dc63f",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
    marginBottom: 10,
  },
  searchButtonText: {
    color: "white",
    fontWeight: "bold",
  },
  recipeItem: {
    padding: 10,
    borderWidth: 1,
    borderColor: "gray",
    borderRadius: 5,
    marginBottom: 10,
  },
  adjustmentContainer: {
    marginTop: 20,
  },
  adjustmentLabel: {
    fontSize: 16,
    marginBottom: 5,
  },
  servingsInput: {
    height: 40,
    borderColor: "gray",
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  adjustButton: {
    backgroundColor: "green",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
  },
  adjustButtonText: {
    color: "white",
    fontWeight: "bold",
  },
  adjustedIngredientsContainer: {
    marginTop: 20,
  },
  adjustedIngredientsLabel: {
    fontSize: 16,
    marginBottom: 5,
  },
});

export default RecipeAdjustmentScreen;
