import React from "react";
import { View } from "react-native";
import PropTypes from "prop-types";
import styles from "./styles";
import MenuButton from "../../components/MenuButton/MenuButton";

export default function DrawerContainer(props) {
  const { navigation } = props;
  const handleLogout = async () => {
    navigation.navigate('LoginScreen');
    navigation.closeDrawer();
  };

  return (
    <View style={styles.content}>
      <View style={styles.container}>
       
        <MenuButton
          title="RECIPES CATEGORIES"
          source={require("../../../assets/icons/category.png")}
          onPress={() => {
            navigation.navigate("Categories");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="RECIPES SEARCH"
          source={require("../../../assets/icons/search.png")}
          onPress={() => {
            navigation.navigate("Search");
            navigation.closeDrawer();
          }}
        />
        
        <MenuButton
          title="INGREDIENTS SUBSTITUTE"
          source={require("../../../assets/icons/IS.jpg")}
          onPress={() => {
            navigation.navigate("IngredientSubstitutes");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="INGREDIENTS INFORMATION"
          source={require("../../../assets/icons/INC.png")}
          onPress={() => {
            navigation.navigate("IngredientInformation");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="INGREDIENTS AMOUNT COMPUTATION"
           source={require("../../../assets/icons/IA.png")}
          onPress={() => {
            navigation.navigate("IngredientAmount");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="RECIPE ADJUSTMENT"
          source={require("../../../assets/icons/Recipe.png")}
          onPress={() => {0
            navigation.navigate("RecipeAdjustmentScreen");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="NUTRITIONAL EDUCATION"
           source={require("../../../assets/icons/NE.png")}
          onPress={() => {
            navigation.navigate("NutritionScreen");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="MEAL PLAN ACCESS"
           source={require("../../../assets/icons/MP.png")}
          onPress={() => {
            navigation.navigate("MealPlanAccessScreen");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="GROCERY LIST CREATION"
           source={require("../../../assets/icons/GL.png")}
          onPress={() => {
            navigation.navigate("GroceryList");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="PROFILE MANAGEMENT"
          source={require("../../../assets/icons/profile.webp")}
          onPress={() => {
            navigation.navigate("ProfileManagementScreen");
            navigation.closeDrawer();
          }}
        />
        <MenuButton
          title="LOGOUT"
          source={require("../../../assets/icons/logout.jpg")} // Change the icon path accordingly
          onPress={handleLogout}
      
        />
       
        
      </View>
    </View>
  );
}

DrawerContainer.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired,
    closeDrawer: PropTypes.func.isRequired,
  }),
};
