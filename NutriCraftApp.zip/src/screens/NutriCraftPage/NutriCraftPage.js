import React from 'react';
import { View, Text, Image, ImageBackground, TouchableOpacity, StyleSheet } from 'react-native';

// Create the NutriCraftPage component
const NutriCraftPage = ({ navigation }) => {
  // Function to handle navigation to the login page
  const handleLogin = () => {
    navigation.navigate('LoginScreen');
  };

  // Function to handle navigation to the signup page
  const handleSignup = () => {
    navigation.navigate('Signup');
  };

  return (
    <ImageBackground
      source={require('../../../assets//icons/MainPage.jpg')} // Change the image path accordingly
      style={styles.background}
    >
      <View style={styles.container}>
        {/* NutriCraft Logo */}
        {/* <Image
          source={require('../../../assets/icons/NutriCraft.png')}
          style={styles.logo}
        /> */}

        {/* Application Name */}
        <Text style={styles.appName}>Nutri Craft</Text>

        {/* Login Button */}
        <TouchableOpacity style={styles.button} onPress={handleLogin}>
          <Text style={styles.buttonText}>Login</Text>
        </TouchableOpacity>

        {/* Signup Button */}
        <TouchableOpacity style={styles.button} onPress={handleSignup}>
          <Text style={styles.buttonText}>Signup</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

// Styles
const styles = StyleSheet.create({
  background: {
    flex: 1,
    resizeMode: 'cover', // or 'stretch'
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-end',
  
    backgroundColor: 'rgba(0,0,0,0.25)', // Set your background color with some opacity
  },
  logo: {
    width: 250, // Adjust based on your logo dimensions
    height: 250, // Adjust based on your logo dimensions
    marginBottom: 20,
  },
  appName: {
    fontSize: 34,
    fontWeight: 'bold',
    marginBottom: 50,
    color: 'white',
    marginEnd: 25,
  },
  button: {
    backgroundColor: 'green', // Set your button color
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    width: 200, // Adjust based on your design
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff', // Set your button text color
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default NutriCraftPage;
