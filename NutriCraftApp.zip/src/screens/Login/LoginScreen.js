import { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, Button, Image, ImageBackground } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from "../../../firebase";

const LoginScreen = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginAs, setLoginAs] = useState('Client');
  const navigation = useNavigation();

  const [signupData, setSignupData] = useState({
    usernameFromSignup: '', // Use the username entered during signup
    passwordFromSignup: '', // Use the password entered during signup
  });
  
  
  const handleLogin = async () => {
    // Implement your signup logic here
    try {
      const userCredential = await signInWithEmailAndPassword(auth, username, password);
      const user = userCredential.user;
      console.log("user data,", user);
      navigation.navigate('FrontScreen');
    } catch (error) {
      const errorCode = error.code;
      const errorMessage = error.message;
      console.log('Error Code == ', errorCode);
      console.log('Error Message == ', errorMessage);
      navigation.navigate('Signup');
    }
  };
   
  const handleSignupNavigation = () => {
    navigation.navigate('Signup');
  };

  return (
    <ImageBackground
      source={require('../../../assets/icons/SignUp.png')} // Change the image path accordingly
      style={styles.backgroundImage}
    >
    <View style={styles.container}>
      <Text style={styles.title}>Login</Text>

      <Text style={styles.label}>Username</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter username"
        onChangeText={(text) => setUsername(text)}
        value={username}
      />

      <Text style={styles.label}>Password</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter password"
        onChangeText={(text) => setPassword(text)}
        value={password}
        secureTextEntry={true}
      />

      <View style={styles.buttonsContainer}>
        <Button title="Login" color="#8dc63f" onPress={handleLogin} />
      </View>

      <View style={styles.signupAsContainer}>
        <Text style={styles.signupText}>Don't have an account?</Text>
        <Button title="Sign Up" color="#8dc63f" onPress={handleSignupNavigation} />
      </View>

      <View style={styles.logosContainer}>
        {/* <Image source={require('./assets/fb.jpg')} style={styles.logo} />
        <Image source={require('./assets/google.webp')} style={styles.logo} /> */}
      </View>
    </View>
    </ImageBackground>
  );
};
const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
    resizeMode: 'cover'
  },
  container: {
    padding: 70,
    backgroundColor: 'rgba(0,0,0,0)',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333', // Text color
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fff', // Input background color
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    color: '#333',
  },
  signupAsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  signupAsLabel: {
    fontSize: 16,
    marginRight: 10,
    color: '#333',
  },
  dropdown: {
    width: 150,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    padding: 10,
    backgroundColor: '#fff',
  },
  buttonsContainer: {
    marginBottom: 20,
  },
  logosContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  logo: {
    width: 50,
    height: 50,
  },
  loginTextContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loginText: {
    marginRight: 5,
    color: '#333',
  },
});

export default LoginScreen;