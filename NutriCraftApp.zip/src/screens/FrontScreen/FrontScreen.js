import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, ScrollView } from 'react-native';
import { useLayoutEffect } from "react";
import MenuImage from "../../components/MenuImage/MenuImage";
import Icon from 'react-native-vector-icons/FontAwesome'; // Replace 'FontAwesome' with the icon set you prefer
import HomeScreen from '../Home/HomeScreen';



const FrontScreen = ({ navigation }) => {
  useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () => (
        <MenuImage
          onPress={() => {
            navigation.openDrawer();
          }}
        />
      ),
      headerRight: () => <View />,
    });
  }, []);

  const [dailyTips, setDailyTips] = useState([
    { id: 1, title: 'Tip 1: Eat a balanced breakfast every morning.' },
    { id: 2, title: 'Tip 2: Include a variety of colorful vegetables in your meals.' },
    { id: 3, title: 'Tip 3: Get at least 7-8 hours of quality sleep each night.' },
  ]);

  const [dailyChallenges, setDailyChallenges] = useState([
    { id: 1, title: 'Challenge 1: Take the stairs instead of the elevator today.' },
    { id: 2, title: 'Challenge 2: Go for a 30-minute walk in the evening.' },
    { id: 3, title: 'Challenge 3: Try a new healthy recipe for dinner.' },
  ]);

  const [healthyReminders, setHealthyReminders] = useState([
    { id: 1, text: 'Drink at least 8 glasses of water today.' },
    { id: 2, text: 'Take a 10-minute walk during your lunch break.' },
    { id: 3, text: 'Include a serving of green vegetables in your dinner.' },
  ]);

  useEffect(() => {
    // Fetch Daily Tips and Daily Challenges (Replace with actual API fetch if needed)
  }, []);

  return (
    <ScrollView contentContainerStyle={styles.scrollViewContainer}>
     
      <View style={styles.container}>
        <Text style={styles.title}>HI ALEEZA!</Text>

       

        {/* Healthy Reminders Section */}
        <View style={[styles.section, { backgroundColor: '#8DC63F' }]}>
          <View style={styles.sectionHeader}>
            <Icon name="heart" size={24} color="white" style={styles.icon} />
            <Text style={[styles.sectionTitle, { color: 'white' }]}>Healthy Reminders</Text>
          </View>
           {/* Image Section */}
        <Image
          source={require('../../../assets/icons/HR.png')}
          style={{ width: 300, height: 170, marginBottom: 20, margin:20 }}
        />
          <FlatList
            data={healthyReminders}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.listItem, { backgroundColor: 'white' }]}>
                <Text style={{ color: 'black' }}>{item.text}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        
        {/* Daily Tips Section */}
        <View style={[styles.section, { backgroundColor: '#8DC63F' }]}>
          <View style={styles.sectionHeader}>
            <Icon name="lightbulb-o" size={24} color="white" style={styles.icon} />
            <Text style={[styles.sectionTitle, { color: 'white' }]}>Daily Tips</Text>
          </View>
          <Image
          source={require('../../../assets/icons/Tip.png')}
          style={{ width: 300, height: 170, marginBottom: 20, margin:20 }}
        />
          <FlatList
            data={dailyTips}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.listItem, { backgroundColor: 'white' }]}>
                <Text style={{ color: 'black' }}>{item.title}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
       
        {/* Daily Challenges Section */}
        <View style={[styles.section, { backgroundColor: '#8DC63F' }]}>
          <View style={styles.sectionHeader}>
            <Icon name="flag-checkered" size={24} color="white" style={styles.icon} />
            <Text style={[styles.sectionTitle, { color: 'white' }]}>Daily Challenges</Text>
            
          </View>
          <Image
          source={require('../../../assets/icons/challenge.png')}
          style={{ width: 350, height: 150, marginBottom: 20 ,}}
        />
          <FlatList
            data={dailyChallenges}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity style={[styles.listItem, { backgroundColor: 'white' }]}>
                <Text style={{ color: 'black' }}>{item.title}</Text>
              </TouchableOpacity>
            )}
          />
        </View>

        {/* Add other sections as needed */}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollViewContainer: {
    flexGrow: 1,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#8dc63f',
    marginBottom: 20,
  },
  section: {
    width: '100%',
    marginBottom: 20,
    borderRadius: 10,
    padding: 10,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 10,
  },
  icon: {
    marginRight: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    paddingLeft: 10,
    color: 'white',
  },
  listItem: {
    padding: 10,
    borderRadius: 8,
    marginBottom: 5,
    backgroundColor: 'white',
  },
});

export default FrontScreen;
