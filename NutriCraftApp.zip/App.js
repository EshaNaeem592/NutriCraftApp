import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import AppContainer from './src/navigations/AppNavigation';


function MyTabs(){
  return(
    <Tab.Navigator>
      <Tab.Screen name="Home" component={AppContainer} />
      <Tab.Screen name="Settings" component={AppContainer} />
    </Tab.Navigator>
  )
}
export default function App() {
  return (
     <AppContainer />
  );
}
